export const singles ={
  links: [
],
nodes: [
  {
    id: "A",
    color: "DarkKhaki"
  },
  {
    id: "B",
    color: "DarkKhaki"
  },
  {
    id: "C",
    color: "DarkKhaki"
  },
  {
    id: "D",
    color: "DarkKhaki"
  },
  {
    id: "E",
    color: "DarkKhaki"
  },
  {
    id: "F",
    color: "DarkKhaki"
  },
  {
    id: "G",
    color: "DarkKhaki"
  },
  {
    id: "H",
    color: "DarkKhaki"
  },
  {
    id: "I",
    color: "DarkKhaki"
  },
  {
    id: "J",
    color: "DarkKhaki"
  },
  {
    id: "K",
    color: "DarkKhaki"
  },
  {
    id: "L",
    color: "DarkKhaki"
  },
  {
    id: "M",
    color: "DarkKhaki"
  },
  {
    id: "N",
    color: "DarkKhaki"
  },
  {
    id: "14",
    color: "DarkKhaki"
  },
  {
    id: "15",
    color: "DarkKhaki"
  },
  {
    id: "16",
    color: "DarkKhaki"
  },
  {
    id: "17",
    color: "DarkKhaki"
  },
  {
    id: "18",
    color: "DarkKhaki"
  },
  {
    id: "19",
    color: "DarkKhaki"
  },
  {
    id: "20",
    color: "DarkKhaki"
  },
  {
    id: "21",
    color: "DarkKhaki"
  },
  {
    id: "22",
    color: "DarkKhaki"
  },
  {
    id: "23",
    color: "DarkKhaki"
  },
  {
    id: "24",
    color: "DarkKhaki"
  },
  {
    id: "25",
    color: "DarkKhaki"
  },
  {
    id: "26",
    color: "DarkKhaki"
  },
  {
    id: "27",
    color: "DarkKhaki"
  },
  {
    id: "28",
    color: "DarkKhaki"
  },
  {
    id: "29",
    color: "DarkKhaki"
  },
  {
    id: "30",
    color: "DarkKhaki"
  },
  {
    id: "31",
    color: "DarkKhaki"
  },
  {
    id: "32",
    color: "DarkKhaki"
  },
  {
    id: "33",
    color: "DarkKhaki"
  },
  {
    id: "34",
    color: "DarkKhaki"
  },
  {
    id: "35",
    color: "DarkKhaki"
  },
  {
    id: "36",
    color: "DarkKhaki"
  },
  {
    id: "37",
    color: "DarkKhaki"
  },
  {
    id: "38",
    color: "DarkKhaki"
  },
  {
    id: "39",
    color: "DarkKhaki"
  },
  {
    id: "40",
    color: "DarkKhaki"
  },
  {
    id: "41",
    color: "DarkKhaki"
  },
  {
    id: "42",
    color: "DarkKhaki"
  },
  {
    id: "43",
    color: "DarkKhaki"
  },
  {
    id: "44",
    color: "DarkKhaki"
  },
  {
    id: "45",
    color: "DarkKhaki"
  },
  {
    id: "46",
    color: "DarkKhaki"
  },
  {
    id: "47",
    color: "DarkKhaki"
  },
  {
    id: "48",
    color: "DarkKhaki"
  },
  {
    id: "49",
    color: "DarkKhaki"
  },
  {
    id: "50",
    color: "DarkKhaki"
  },
  {
    id: "51",
    color: "DarkKhaki"
  },
  {
    id: "52",
    color: "DarkKhaki"
  },
  {
    id: "53",
    color: "DarkKhaki"
  },
  {
    id: "54",
    color: "DarkKhaki"
  },
  {
    id: "55",
    color: "DarkKhaki"
  },
  {
    id: "56",
    color: "DarkKhaki"
  },
  {
    id: "57",
    color: "DarkKhaki"
  },
  {
    id: "58",
    color: "DarkKhaki"
  },
  {
    id: "59",
    color: "DarkKhaki"
  },
  {
    id: "60",
    color: "DarkKhaki"
  },
  {
    id: "61",
    color: "DarkKhaki"
  },
  {
    id: "62",
    color: "DarkKhaki"
  },
  {
    id: "63",
    color: "DarkKhaki"
  },
  {
    id: "64",
    color: "DarkKhaki"
  },
  {
    id: "65",
    color: "DarkKhaki"
  },
  {
    id: "66",
    color: "DarkKhaki"
  },
  {
    id: "67",
    color: "DarkKhaki"
  },
  {
    id: "68",
    color: "DarkKhaki"
  },
  {
    id: "69",
    color: "DarkKhaki"
  },
  {
    id: "70",
    color: "DarkKhaki"
  },
  {
    id: "71",
    color: "DarkKhaki"
  },
  {
    id: "72",
    color: "DarkKhaki"
  },
  {
    id: "73",
    color: "DarkKhaki"
  },
  {
    id: "74",
    color: "DarkKhaki"
  },
  {
    id: "75",
    color: "DarkKhaki"
  },
  {
    id: "76",
    color: "DarkKhaki"
  },
  {
    id: "77",
    color: "DarkKhaki"
  },
  {
    id: "78",
    color: "DarkKhaki"
  },
  {
    id: "79",
    color: "DarkKhaki"
  },
  {
    id: "80",
    color: "DarkKhaki"
  },
  {
    id: "81",
    color: "DarkKhaki"
  },
  {
    id: "82",
    color: "DarkKhaki"
  },
  {
    id: "83",
    color: "DarkKhaki"
  },
  {
    id: "84",
    color: "DarkKhaki"
  },
  {
    id: "85",
    color: "DarkKhaki"
  },
  {
    id: "86",
    color: "DarkKhaki"
  },
  {
    id: "87",
    color: "DarkKhaki"
  },
  {
    id: "88",
    color: "DarkKhaki"
  },
  {
    id: "89",
    color: "DarkKhaki"
  },
  {
    id: "90",
    color: "DarkKhaki"
  },
  {
    id: "91",
    color: "DarkKhaki"
  },
  {
    id: "92",
    color: "DarkKhaki"
  },
  {
    id: "93",
    color: "DarkKhaki"
  },
  {
    id: "94",
    color: "DarkKhaki"
  },
  {
    id: "95",
    color: "DarkKhaki"
  },
  {
    id: "96",
    color: "DarkKhaki"
  },
  {
    id: "97",
    color: "DarkKhaki"
  },
  {
    id: "98",
    color: "DarkKhaki"
  },
  {
    id: "99",
    color: "DarkKhaki"
  }
]
}

export default singles;