export const airport ={
    links: [
  {
     source: "28",
    target: "32",
     
  },
  {
     source: "28",
    target: "31"
  },
  {
     source: "28",
    target: "29"
  },
  {
     source: "28",
    target: "29"
  },
  {
     source: "28",
    target: "15"
  },
  {
     source: "28",
    target: "30"
  },
  {
     source: "28",
    target: "33"
  },
  {
     source: "28",
    target: "17"
  },
  {
     source: "28",
    target: "27",
     
  },
  {
     source: "28",
    target: "26",
     
  },
  {
     source: "53",
    target: "51"
  },
  {
     source: "53",
    target: "88"
  },
  {
     source: "53",
    target: "49",
     
  },
  {
     source: "53",
    target: "50"
  },
  {
     source: "53",
    target: "27"
  },
  {
     source: "53",
    target: "33",
     
  },
  {
     source: "53",
    target: "31",
     
  },
  {
     source: "53",
    target: "39"
  },
  {
     source: "53",
    target: "61",
     
  },
  {
     source: "53",
    target: "45",
     
  },
  {
     source: "53",
    target: "62",
     
  },
  {
     source: "53",
    target: "29",
     
  },
  {
     source: "53",
    target: "15",
     
  },
  {
     source: "53",
    target: "30",
     
  },
  {
     source: "53",
    target: "17",
     
  },
  {
     source: "53",
    target: "26",
     
  },
  {
     source: "44",
    target: "55"
  },
  {
     source: "44",
    target: "M"
  },
  {
     source: "44",
    target: "38",
     
  },
  {
     source: "44",
    target: "F",
     
  },
  {
     source: "44",
    target: "L",
     
  },
  {
     source: "44",
    target: "E"
  },
  {
     source: "44",
    target: "A",
     
  },
  {
     source: "44",
    target: "B"
  },
  {
     source: "44",
    target: "B",
     
  },
  {
     source: "44",
    target: "I",
     
  },
  {
     source: "44",
    target: "56",
     
  },
  {
     source: "44",
    target: "J"
  },
  {
     source: "44",
    target: "63",
     
  },
  {
     source: "44",
    target: "40"
  },
  {
     source: "44",
    target: "40"
  },
  {
     source: "J",
    target: "63"
  },
  {
     source: "J",
    target: "40"
  },
  {
     source: "J",
    target: "I"
  },
  {
     source: "J",
    target: "56"
  },
  {
     source: "J",
    target: "44",
     
  },
  {
     source: "J",
    target: "55"
  },
  {
     source: "J",
    target: "M"
  },
  {
     source: "J",
    target: "B"
  },
  {
     source: "J",
    target: "A"
  },
  {
     source: "J",
    target: "38"
  },
  {
     source: "J",
    target: "F"
  },
  {
     source: "J",
    target: "L"
  },
  {
     source: "J",
    target: "E",
     
  },
  {
     source: "22",
    target: "54"
  },
  {
     source: "22",
    target: "54"
  },
  {
     source: "22",
    target: "21"
  },
  {
     source: "22",
    target: "21"
  },
  {
     source: "22",
    target: "16"
  },
  {
     source: "22",
    target: "16"
  },
  {
     source: "22",
    target: "18",
     
  },
  {
     source: "22",
    target: "20"
  },
  {
     source: "22",
    target: "19",
     
  },
  {
     source: "22",
    target: "25"
  },
  {
     source: "22",
    target: "46"
  },
  {
     source: "22",
    target: "14",
     
  },
  {
     source: "22",
    target: "24",
     
  },
  {
     source: "22",
    target: "23"
  },
  {
     source: "22",
    target: "23"
  },
  {
     source: "22",
    target: "54",
     
  },
  {
     source: "22",
    target: "65"
  },
  {
     source: "22",
    target: "65",
     
  },
  {
     source: "22",
    target: "41",
     
  },
  {
     source: "42",
    target: "64",
     
  },
  {
     source: "42",
    target: "57",
     
  },
  {
     source: "42",
    target: "G"
  },
  {
     source: "42",
    target: "43"
  },
  {
     source: "42",
    target: "60"
  },
  {
     source: "42",
    target: "C"
  },
  {
     source: "42",
    target: "C"
  },
  {
     source: "42",
    target: "K"
  },
  {
     source: "42",
    target: "H"
  },
  {
     source: "42",
    target: "H"
  },
  {
     source: "42",
    target: "58"
  },
  {
     source: "42",
    target: "N",
     
  },
  {
     source: "42",
    target: "48"
  },
  {
     source: "42",
    target: "47",
     
  },
  {
     source: "42",
    target: "59"
  },
  {
     source: "48",
    target: "47"
  },
  {
    source: "48",
    target: "52"
  },
  {
     source: "48",
    target: "59"
  },
  {
     source: "48",
    target: "N"
  },
  {
     source: "48",
    target: "64",
     
  },
  {
     source: "57",
    target: "G",
     
  },
  {
     source: "57",
    target: "43",
     
  },
  {
     source: "57",
    target: "60"
  },
  {
     source: "57",
    target: "58",
     
  },
  {
     source: "57",
    target: "C",
     
  },
  {
     source: "57",
    target: "K",
     
  },
  {
     source: "57",
    target: "H"
  },
  {
     source: "83",
    target: "81",
     
  },
  {
     source: "83",
    target: "94",
     
  },
  {
     source: "83",
    target: "95",
     
  },
  {
     source: "83",
    target: "89",
     
  },
  {
     source: "83",
    target: "91"
  },
  {
     source: "83",
    target: "90",
     
  },
  {
     source: "83",
    target: "85"
  },
  {
     source: "83",
    target: "86"
  },
  {
     source: "83",
    target: "93"
  },
  {
     source: "83",
    target: "97",
     
  },
  {
     source: "83",
    target: "99"
  },
  {
     source: "83",
    target: "92",
     
  },
  {
     source: "83",
    target: "82"
  },
  {
     source: "83",
    target: "96",
     
  },
  {
     source: "83",
    target: "98",
     
  },
  {
     source: "96",
    target: "87",
     
  },
  {
     source: "96",
    target: "91"
  },
  {
     source: "96",
    target: "86"
  },
  {
     source: "96",
    target: "90"
  },
  {
     source: "96",
    target: "90"
  },
  {
     source: "96",
    target: "85",
     
  },
  {
     source: "99",
    target: "82"
  },
  {
     source: "99",
    target: "92"
  },
  {
     source: "99",
    target: "98"
  },
  {
     source: "99",
    target: "97"
  },
  {
     source: "71",
    target: "75"
  },
  {
     source: "71",
    target: "70",
     
  },
  {
     source: "71",
    target: "78"
  },
  {
     source: "71",
    target: "67"
  },
  {
     source: "71",
    target: "74"
  },
  {
     source: "71",
    target: "72"
  },
  {
     source: "71",
    target: "79"
  },
  {
     source: "71",
    target: "77",
     
  },
  {
     source: "71",
    target: "36"
  },
  {
     source: "71",
    target: "73"
  },
  {
     source: "71",
    target: "76",
     
  },
  {
     source: "71",
    target: "69",
     
  },
  {
     source: "71",
    target: "37",
     
  },
  {
     source: "71",
    target: "35",
     
  },
  {
     source: "71",
    target: "80",
     
  },
  {
     source: "71",
    target: "66",
     
  },
  {
     source: "71",
    target: "84"
  },
  {
     source: "71",
    target: "84",
     
  },
  {
     source: "71",
    target: "34"
  },
  {
     source: "68",
    target: "70"
  },
  {
     source: "68",
    target: "78"
  },
  {
     source: "68",
    target: "78"
  },
  {
     source: "68",
    target: "75"
  },
  {
     source: "68",
    target: "74"
  },
  {
     source: "68",
    target: "69"
  },
  {
     source: "68",
    target: "76"
  },
  {
     source: "68",
    target: "73"
  },
  {
     source: "68",
    target: "73"
  },
  {
     source: "68",
    target: "37"
  },
  {
     source: "68",
    target: "35"
  },
  {
     source: "68",
    target: "80"
  },
  {
     source: "68",
    target: "66"
  },
  {
     source: "68",
    target: "66"
  },
  {
     source: "16",
    target: "21"
  },
  {
     source: "16",
    target: "41"
  },
  {
     source: "16",
    target: "65"
  },
  {
     source: "16",
    target: "65"
  },
  {
     source: "16",
    target: "54"
  },
  {
     source: "16",
    target: "18"
  },
  {
     source: "16",
    target: "20",
     
  },
  {
     source: "16",
    target: "19"
  },
  {
     source: "16",
    target: "25",
     
  },
  {
     source: "16",
    target: "46",
     
  },
  {
     source: "16",
    target: "54"
  },
  {
     source: "16",
    target: "14"
  },
  {
     source: "16",
    target: "24",
     
  },
  {
     source: "16",
    target: "23"
  },
  {
     source: "D",
    target: "G",
     
  },
  {
     source: "D",
    target: "19",
     
  },
  {
     source: "D",
    target: "44",
     
  },
  {
     source: "D",
    target: "45",
     
  },
  {
     source: "D",
    target: "84",
     
  },
  {
     source: "D",
    target: "89",
     
  }
],
nodes: [
    {
      id: "A",
      color: "DarkKhaki"
    },
    {
      id: "B",
      color: "DarkKhaki"
    },
    {
      id: "C",
      color: "DarkKhaki"
    },
    {
      id: "D",
      color: "DarkKhaki"
    },
    {
      id: "E",
      color: "DarkKhaki"
    },
    {
      id: "F",
      color: "DarkKhaki"
    },
    {
      id: "G",
      color: "DarkKhaki"
    },
    {
      id: "H",
      color: "DarkKhaki"
    },
    {
      id: "I",
      color: "DarkKhaki"
    },
    {
      id: "J",
      color: "DarkKhaki"
    },
    {
      id: "K",
      color: "DarkKhaki"
    },
    {
      id: "L",
      color: "DarkKhaki"
    },
    {
      id: "M",
      color: "DarkKhaki"
    },
    {
      id: "N",
      color: "DarkKhaki"
    },
    {
      id: "14",
      color: "DarkKhaki"
    },
    {
      id: "15",
      color: "DarkKhaki"
    },
    {
      id: "16",
      color: "DarkKhaki"
    },
    {
      id: "17",
      color: "DarkKhaki"
    },
    {
      id: "18",
      color: "DarkKhaki"
    },
    {
      id: "19",
      color: "DarkKhaki"
    },
    {
      id: "20",
      color: "DarkKhaki"
    },
    {
      id: "21",
      color: "DarkKhaki"
    },
    {
      id: "22",
      color: "DarkKhaki"
    },
    {
      id: "23",
      color: "DarkKhaki"
    },
    {
      id: "24",
      color: "DarkKhaki"
    },
    {
      id: "25",
      color: "DarkKhaki"
    },
    {
      id: "26",
      color: "DarkKhaki"
    },
    {
      id: "27",
      color: "DarkKhaki"
    },
    {
      id: "28",
      color: "DarkKhaki"
    },
    {
      id: "29",
      color: "DarkKhaki"
    },
    {
      id: "30",
      color: "DarkKhaki"
    },
    {
      id: "31",
      color: "DarkKhaki"
    },
    {
      id: "32",
      color: "DarkKhaki"
    },
    {
      id: "33",
      color: "DarkKhaki"
    },
    {
      id: "34",
      color: "DarkKhaki"
    },
    {
      id: "35",
      color: "DarkKhaki"
    },
    {
      id: "36",
      color: "DarkKhaki"
    },
    {
      id: "37",
      color: "DarkKhaki"
    },
    {
      id: "38",
      color: "DarkKhaki"
    },
    {
      id: "39",
      color: "DarkKhaki"
    },
    {
      id: "40",
      color: "DarkKhaki"
    },
    {
      id: "41",
      color: "DarkKhaki"
    },
    {
      id: "42",
      color: "DarkKhaki"
    },
    {
      id: "43",
      color: "DarkKhaki"
    },
    {
      id: "44",
      color: "DarkKhaki"
    },
    {
      id: "45",
      color: "DarkKhaki"
    },
    {
      id: "46",
      color: "DarkKhaki"
    },
    {
      id: "47",
      color: "DarkKhaki"
    },
    {
      id: "48",
      color: "DarkKhaki"
    },
    {
      id: "49",
      color: "DarkKhaki"
    },
    {
      id: "50",
      color: "DarkKhaki"
    },
    {
      id: "51",
      color: "DarkKhaki"
    },
    {
      id: "52",
      color: "DarkKhaki"
    },
    {
      id: "53",
      color: "DarkKhaki"
    },
    {
      id: "54",
      color: "DarkKhaki"
    },
    {
      id: "55",
      color: "DarkKhaki"
    },
    {
      id: "56",
      color: "DarkKhaki"
    },
    {
      id: "57",
      color: "DarkKhaki"
    },
    {
      id: "58",
      color: "DarkKhaki"
    },
    {
      id: "59",
      color: "DarkKhaki"
    },
    {
      id: "60",
      color: "DarkKhaki"
    },
    {
      id: "61",
      color: "DarkKhaki"
    },
    {
      id: "62",
      color: "DarkKhaki"
    },
    {
      id: "63",
      color: "DarkKhaki"
    },
    {
      id: "64",
      color: "DarkKhaki"
    },
    {
      id: "65",
      color: "DarkKhaki"
    },
    {
      id: "66",
      color: "DarkKhaki"
    },
    {
      id: "67",
      color: "DarkKhaki"
    },
    {
      id: "68",
      color: "DarkKhaki"
    },
    {
      id: "69",
      color: "DarkKhaki"
    },
    {
      id: "70",
      color: "DarkKhaki"
    },
    {
      id: "71",
      color: "DarkKhaki"
    },
    {
      id: "72",
      color: "DarkKhaki"
    },
    {
      id: "73",
      color: "DarkKhaki"
    },
    {
      id: "74",
      color: "DarkKhaki"
    },
    {
      id: "75",
      color: "DarkKhaki"
    },
    {
      id: "76",
      color: "DarkKhaki"
    },
    {
      id: "77",
      color: "DarkKhaki"
    },
    {
      id: "78",
      color: "DarkKhaki"
    },
    {
      id: "79",
      color: "DarkKhaki"
    },
    {
      id: "80",
      color: "DarkKhaki"
    },
    {
      id: "81",
      color: "DarkKhaki"
    },
    {
      id: "82",
      color: "DarkKhaki"
    },
    {
      id: "83",
      color: "DarkKhaki"
    },
    {
      id: "84",
      color: "DarkKhaki"
    },
    {
      id: "85",
      color: "DarkKhaki"
    },
    {
      id: "86",
      color: "DarkKhaki"
    },
    {
      id: "87",
      color: "DarkKhaki"
    },
    {
      id: "88",
      color: "DarkKhaki"
    },
    {
      id: "89",
      color: "DarkKhaki"
    },
    {
      id: "90",
      color: "DarkKhaki"
    },
    {
      id: "91",
      color: "DarkKhaki"
    },
    {
      id: "92",
      color: "DarkKhaki"
    },
    {
      id: "93",
      color: "DarkKhaki"
    },
    {
      id: "94",
      color: "DarkKhaki"
    },
    {
      id: "95",
      color: "DarkKhaki"
    },
    {
      id: "96",
      color: "DarkKhaki"
    },
    {
      id: "97",
      color: "DarkKhaki"
    },
    {
      id: "98",
      color: "DarkKhaki"
    },
    {
      id: "99",
      color: "DarkKhaki"
    }
  ]
}

export default airport;