export const linedata = [
    {
    label: 'Susceptible',
    values: [{x: 0.1, y: 100}]
    },
    {
    label: 'Infected',
    values: [{x: 0, y: 0}]
    },
    {
    label: 'Recovered',
    values: [{x: 0, y: 0}]
    }
];

export default linedata;